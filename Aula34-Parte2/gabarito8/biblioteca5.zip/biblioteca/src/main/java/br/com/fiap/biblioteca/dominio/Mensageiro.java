package br.com.fiap.biblioteca.dominio;

public class Mensageiro {

	public void enviarMensagemA(Aluno aluno) {
		// TODO Auto-generated method stub
		
	}

}
